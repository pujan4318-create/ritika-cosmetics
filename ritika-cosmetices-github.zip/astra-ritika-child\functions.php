<?php
/**
 * Ritika Cosmetices Theme functions and definitions
 */

// 1. Enqueue Parent Theme Styles
function astra_ritika_child_enqueue_styles() {
    wp_enqueue_style( 'astra-parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'astra-ritika-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( 'astra-parent-style' ),
        wp_get_theme()->get('Version')
    );
}
add_action( 'wp_enqueue_scripts', 'astra_ritika_child_enqueue_styles' );

// 2. Add Price Disclaimer below WooCommerce Prices
// This fulfills the requirement: "Because cosmetic prices change, add: Prices may vary..."
function ritika_add_price_disclaimer() {
    echo '<div class="ritika-price-disclaimer">Prices may vary depending on brand, size, shade and availability. Please contact the shop for the latest price.</div>';
}
// Add to product catalog cards
add_action( 'woocommerce_after_shop_loop_item_title', 'ritika_add_price_disclaimer', 15 );
// Add to single product page
add_action( 'woocommerce_single_product_summary', 'ritika_add_price_disclaimer', 15 );

// 3. Add WhatsApp Floating Button to Footer
// This fulfills the requirement: "put api chat with using my given whatsapp number"
function ritika_add_whatsapp_button() {
    ?>
    <a href="https://wa.me/9779847809266" class="float-whatsapp" target="_blank" rel="noopener noreferrer" aria-label="Chat with Ritika Cosmetices on WhatsApp">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2022 Fonticons, Inc.--><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zM223.9 414.7c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 334.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-2.1-3.6 2.1-3.2 7.6-14.2 2.7-5.5 1.4-10.2-0.5-13.9-1.9-3.7-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>
    </a>
    <?php
}
add_action( 'wp_footer', 'ritika_add_whatsapp_button' );
