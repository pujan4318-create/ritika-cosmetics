# 🌸 RITIKA COSMETICES — Official Website

> **Local cosmetics, beauty, and personal-care shop in Dhankuta, Nepal.**

---

## 📍 Business Information
* **Shop Name:** RITIKA COSMETICES
* **Location:** Chuwa Ko Bot, Dhankuta, Kosi Province, Nepal
* **Phone / WhatsApp:** [+977 9847809266](https://wa.me/9779847809266)
* **Email:** ritikastha2410@gmail.com
* **Opening Hours:** Every Day: 8:00 AM – 6:00 PM

---

## ✨ Features
* **100% Authentic Visuals:** Real shop photographs of the owner, storefront at Chuwa Ko Bot, and in-store product display shelves. No AI-generated fake imagery.
* **Astra Theme Aesthetic:** Soft neutral background (`#fdfcfb`), Playfair Display typography, and soft gold accents.
* **Nepal Market Pricing:** Realistic market price ranges in NPR (Rs.) with automatic price disclaimers.
* **Instant WhatsApp Ordering:** Every product card and the interactive shopping cart connect directly to WhatsApp API (`wa.me/9779847809266`) with pre-formatted product lists and totals.
* **SEO Optimized for Nepal:** Schema.org `LocalBusiness` JSON-LD structured data for Google local search and maps visibility in Dhankuta.
* **Mobile-First UX:** High-speed, lightweight static architecture with instant client-side category filtering.

---

## 📂 Project Structure
```text
ritika-cosmetices/
├── index.html                 # Main website (catalog, cart, about, gallery, blog, contact)
├── vercel.json                # Vercel configuration (caching, security headers, clean URLs)
├── package.json               # Project manifest
├── .gitignore                 # Git ignore rules
├── README.md                  # Project documentation
├── images/                    # Authentic shop photographs
│   ├── ritika-cosmetices-owner.jpg
│   ├── ritika-cosmetices-shop-nepal.jpg
│   └── ritika-cosmetices-store-interior.jpg
└── astra-ritika-child/        # WordPress Astra Child Theme files
    ├── style.css              # Custom styling
    └── functions.php          # WooCommerce hooks and WhatsApp widget
```

---

## 🚀 How to Push to GitHub & Deploy on Vercel

### Step 1: Push to GitHub
1. Create a new repository on [GitHub](https://github.com/new) named `ritika-cosmetices`.
2. In this folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Ritika Cosmetices official website"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/ritika-cosmetices.git
   git push -u origin main
   ```

### Step 2: Deploy to Vercel (Automatic Continuous Deployment)
1. Go to [https://vercel.com/new](https://vercel.com/new).
2. Connect your GitHub account and select the **ritika-cosmetices** repository.
3. Keep default settings (Framework: **Other**) and click **Deploy**.
4. Every time you push a change to GitHub, Vercel will automatically rebuild and deploy your site!

---

© 2026 Ritika Cosmetices. All rights reserved.
