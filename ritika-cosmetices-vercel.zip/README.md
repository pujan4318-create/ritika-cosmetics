# Ritika Cosmetices — Vercel Deployment Package

This folder contains the complete, production-ready website for **Ritika Cosmetices** (Chuwa Ko Bot, Dhankuta, Nepal), ready for **1-click deployment on Vercel**.

---

## 🚀 How to Deploy on Vercel

### Option 1: Using the Vercel CLI (Instant - 30 seconds)
Open PowerShell in this directory and run:
```bash
vercel
```
1. It will ask: `Set up and deploy?` → Press **Enter** (Yes).
2. Which scope? → Select your personal account.
3. Link to existing project? → **N** (No).
4. Project name? → `ritika-cosmetices` (or press Enter).
5. In which directory is your code located? → Press Enter (`./`).
6. Want to modify these settings? → **N** (No).

Your site will immediately be live on a global Vercel URL (e.g. `https://ritika-cosmetices.vercel.app`)!

To deploy to production with custom domain:
```bash
vercel --prod
```

---

### Option 2: Deploying via GitHub & Vercel Dashboard
1. Push this folder to a new GitHub repository (e.g., `ritika-cosmetices`).
2. Go to [https://vercel.com/new](https://vercel.com/new).
3. Connect your GitHub account and select the `ritika-cosmetices` repo.
4. Leave all build settings as default (Framework Preset: **Other**).
5. Click **Deploy**.

---

## 📁 Package Contents
* `index.html` — Fully optimized, responsive homepage with local SEO, schema markup, product catalog, cart drawer, and WhatsApp checkout.
* `images/` — Authentic photographs of the shop owner, exterior, and interior (no AI-generated imagery).
* `astra-ritika-child/` — Original WordPress Astra Child Theme files (`style.css` and `functions.php`).
* `vercel.json` — Edge caching, security headers, and clean routing rules.
* `package.json` — Vercel project metadata.
